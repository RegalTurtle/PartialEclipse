# Partial Eclipse 8

Creates four artifacts for Eclipse 1, 3, 5, and 8 that apply the eclipse effects to those who vote for them, similar to PartialMetamorphosis.

Works with [EclipseArtifacts](https://thunderstore.io/package/Judgy/EclipseArtifacts/)

- Eclipse 1: Start with 50% health

- Eclipse 3: Fall damage doubled and lethal

- Eclipse 5: 50% healing

- Eclipse 8: 40% of damage you take is applied as curse

Message me on discord if this stops working again, or if you have other questions @regalturtle

# WIP

- Will be working on ways to implement E2, 4, 6, & 7 one sided
