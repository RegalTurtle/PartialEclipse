## 1.3.2

- Added compatibility support for [EclipseArtifacts](https://thunderstore.io/package/Judgy/EclipseArtifacts/)

## 1.3.1

- Typo

## 1.3.0

- Added Eclipse 1 and Eclipse 3
- Rewrote Eclipse 5 and 8 to use preexisting logic instead of writing my own

## 1.2.2

- Fixed typo in Eclipse 5 artifact

## 1.2.1

- Eclipse 5 now supported

## 1.1.0

- SotS update!

## 1.0.0

- Initial Release
